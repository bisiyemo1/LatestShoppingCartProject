	<!--Code for the footer-->
	<div class="panel panel-primary" style="margin-top: -20px;">
	<div class="panel-footer" style="background: black;">

<?php
$startYear = 2018;
$thisYear = date('Y');
if ($thisYear > $startYear) {
	$thisYear = date('Y');
	$copyright = "$startYear &ndash; $thisYear";
} else {
	$copyright = $startYear;
}
/* Then at the footer code where "&copy 2017" is, write in place of 2017
this php code (<?php echo $copyright; ?>)
*/ 
?> 			
		<h5 style="color: white;">&copy; Copyright <?php echo $copyright; ?> VIRTUOSO ELECTRONIC STORE. All rights reserved.</h5>
					
		<div style="float: right; margin-top: -30px;">
			<a href="http://www.facebook.com"><img src="product_images/facebook.jpg" style="width: 30px; height: 30px;" /></a>
			<a href="http://www.gmail.com"><img src="product_images/gmail.jpg" style="width: 30px; height: 30px;" /></a>
			<a href="http://www.yahoomail.com"><img src="product_images/email.jpg" style="width: 30px; height: 30px;" /></a>
			<a href="http://www.youtube.com"><img src="product_images/youtube.jpg" style="width: 30px; height: 30px;" /></a>
			<a href="http://www.twitter.com"><img src="product_images/twitter.jpg" style="width: 30px; height: 30px;" /></a>
		</div>

	</div>
	</div>