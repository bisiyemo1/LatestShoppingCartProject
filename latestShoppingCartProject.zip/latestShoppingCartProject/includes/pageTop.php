<!--Navbar and Header -->
<div class="navbar navbar-inverse navbar-fixed-top" style=" margin-top: -20px; background: #000080;">

		<div class="well well-sm" style="background: blue; color: white; border: none;">
			<div style="margin-left: 50px; margin-bottom: -13px; margin-top: 15px;">
				<h6><span class="glyphicon glyphicon-envelope">info@vestore.epizy.com  <span class="glyphicon glyphicon-earphone">0814-037-4189</span></span></h6>
			</div>
			<div style="float: right; margin-top: -12px; margin-right: 90px;">
				<a href="http://www.facebook.com"><img src="product_images/facebook.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.gmail.com"><img src="product_images/gmail.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.youtube.com"><img src="product_images/youtube.jpg" style="width: 15px; height: 15px;" /></a>
				<a href="http://www.twitter.com"><img src="product_images/twitter.jpg" style="width: 15px; height: 15px;" /></a>
			</div>
		</div>

		<div class="container col-sm-12" style="margin-top: -20px;">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
				<a href="#" class="navbar-brand"><img class="img-responsive" src="product_images/vesLogo.jpg" style="height: 40px; width: 40px; margin-top: -10px; " /><h5 style="margin-left: 50px; margin-top: -25px; color: red;"><strong>Victor Electronics Store</strong></h5></a>

			</div>
			<div class="collapse navbar-collapse" id="collapse">
				<ul class="nav navbar-nav">
					<li><a href="index.php" style="color: white;"><span class="glyphicon glyphicon-home"></span>Home</a></li>
					<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Product</a></li>
				</ul>
			</div>
		</div>
</div>